package com.lucky.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Search and select any item registered by vanilla or an installed mod. */
public class ItemWishScreen extends Screen {
    private static final int PAGE_SIZE = 10;
    private final List<ResourceLocation> allItems = new ArrayList<>();
    private final List<ResourceLocation> filteredItems = new ArrayList<>();
    private final Button[] itemButtons = new Button[PAGE_SIZE];
    private EditBox searchBox;
    private Button previousButton;
    private Button nextButton;
    private int page;
    private int startX;
    private int startY;
    private int buttonWidth;
    private int buttonHeight;
    private int rowStep;

    public ItemWishScreen() {
        super(Component.literal("Lucky Wish Catalogue"));
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == null || item == Items.AIR) continue;
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id != null) allItems.add(id);
        }
        allItems.sort(Comparator.comparing(ResourceLocation::toString));
    }

    @Override
    protected void init() {
        int margin = Math.max(8, this.width / 24);
        int gap = 6;
        buttonWidth = Math.max(80, (this.width - margin * 2 - gap) / 2);
        buttonHeight = this.height < 250 ? 18 : 20;
        rowStep = buttonHeight + 3;
        startX = margin;
        startY = 65;

        searchBox = new EditBox(this.font, margin, 38, this.width - margin * 2, 20,
                Component.literal("Search items"));
        searchBox.setMaxLength(160);
        searchBox.setHint(Component.literal("Search by item name or mod:id"));
        searchBox.setResponder(ignored -> refreshItems());
        addRenderableWidget(searchBox);

        for (int slot = 0; slot < PAGE_SIZE; slot++) {
            final int buttonSlot = slot;
            int x = startX + (slot % 2) * (buttonWidth + gap);
            int y = startY + (slot / 2) * rowStep;
            itemButtons[slot] = Button.builder(Component.literal(""), b -> choose(buttonSlot))
                    .bounds(x, y, buttonWidth, buttonHeight).build();
            addRenderableWidget(itemButtons[slot]);
        }

        int navY = this.height - 52;
        int navWidth = Math.min(100, (this.width - 30) / 3);
        previousButton = Button.builder(Component.literal("‹ Prev"), b -> {
            page = Math.max(0, page - 1);
            refreshItems();
        }).bounds(this.width / 2 - navWidth - 4, navY, navWidth, 20).build();
        addRenderableWidget(previousButton);
        nextButton = Button.builder(Component.literal("Next ›"), b -> {
            page = Math.min(pageCount() - 1, page + 1);
            refreshItems();
        }).bounds(this.width / 2 + 4, navY, navWidth, 20).build();
        addRenderableWidget(nextButton);
        int closeWidth = Math.min(220, this.width - 24);
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose())
                .bounds((this.width - closeWidth) / 2, this.height - 26, closeWidth, 20).build());

        setInitialFocus(searchBox);
        refreshItems();
    }

    private int pageCount() {
        return Math.max(1, (filteredItems.size() + PAGE_SIZE - 1) / PAGE_SIZE);
    }

    private void refreshItems() {
        String query = searchBox == null ? "" : searchBox.getValue().trim().toLowerCase(Locale.ROOT);
        filteredItems.clear();
        for (ResourceLocation id : allItems) {
            Item item = BuiltInRegistries.ITEM.get(id);
            String itemName = item == null ? "" : item.getDescription().getString().toLowerCase(Locale.ROOT);
            if (query.isEmpty() || id.toString().toLowerCase(Locale.ROOT).contains(query) || itemName.contains(query)) {
                filteredItems.add(id);
            }
        }
        page = Math.max(0, Math.min(page, pageCount() - 1));
        for (int slot = 0; slot < PAGE_SIZE; slot++) {
            int index = page * PAGE_SIZE + slot;
            Button button = itemButtons[slot];
            if (button == null) continue;
            boolean available = index < filteredItems.size();
            button.active = available;
            button.setMessage(Component.literal(available ? shortName(filteredItems.get(index)) : "—"));
        }
        if (previousButton != null) previousButton.active = page > 0;
        if (nextButton != null) nextButton.active = page + 1 < pageCount();
    }

    private static String shortName(ResourceLocation id) {
        Item item = BuiltInRegistries.ITEM.get(id);
        String name = item == null ? id.toString() : item.getDescription().getString();
        return name.length() <= 24 ? name : name.substring(0, 21) + "…";
    }

    private void choose(int slot) {
        int index = page * PAGE_SIZE + slot;
        if (index < 0 || index >= filteredItems.size()) return;
        ModNetworking.sendToServer(new WishItemPacket(filteredItems.get(index)));
        onClose();
    }

    private String hoveredId(double mouseX, double mouseY) {
        for (int slot = 0; slot < PAGE_SIZE; slot++) {
            int index = page * PAGE_SIZE + slot;
            if (index >= filteredItems.size()) break;
            int x = startX + (slot % 2) * (buttonWidth + 6);
            int y = startY + (slot / 2) * rowStep;
            if (mouseX >= x && mouseX < x + buttonWidth && mouseY >= y && mouseY < y + buttonHeight) {
                ResourceLocation id = filteredItems.get(index);
                Item item = BuiltInRegistries.ITEM.get(id);
                String name = item == null ? id.toString() : item.getDescription().getString();
                return name + "  •  " + id;
            }
        }
        return "Search by item name or mod:id; select one to receive a stack.";
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(font, title, width / 2, 10, 0xFFFFFF);
        graphics.drawCenteredString(font,
                Component.literal(filteredItems.size() + " matching items  •  Page " + (page + 1) + " / " + pageCount()),
                width / 2, 26, 0xFFD84A);
        graphics.drawCenteredString(font, Component.literal(hoveredId(mouseX, mouseY)), width / 2,
                height - 38, 0xBFEFFF);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
