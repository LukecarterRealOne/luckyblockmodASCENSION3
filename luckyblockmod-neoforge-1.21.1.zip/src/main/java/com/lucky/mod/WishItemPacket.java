package com.lucky.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: grant a chosen registry item after server-side validation. */
public record WishItemPacket(ResourceLocation itemId) implements CustomPacketPayload {
    public static final Type<WishItemPacket> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(LuckyBlockMod.MOD_ID, "wish_item"));
    public static final StreamCodec<ByteBuf, WishItemPacket> STREAM_CODEC = StreamCodec.composite(
            ResourceLocation.STREAM_CODEC, WishItemPacket::itemId,
            WishItemPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public void handleServer(IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        if (!BuiltInRegistries.ITEM.containsKey(itemId)) {
            player.displayClientMessage(Component.literal("That item is not registered on this server."), true);
            return;
        }
        Item item = BuiltInRegistries.ITEM.get(itemId);
        if (item == null || item == Items.AIR) {
            player.displayClientMessage(Component.literal("That item is not registered on this server."), true);
            return;
        }
        int count = Math.max(1, item.getMaxStackSize());
        ItemStack stack = new ItemStack(item, count);
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        player.displayClientMessage(Component.literal("§6Lucky Wish granted: §e" + itemId), true);
    }
}
