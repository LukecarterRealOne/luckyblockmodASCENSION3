package com.lucky.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.DistExecutor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: open the searchable item catalogue for Item Wish. */
public record OpenItemWishPacket() implements CustomPacketPayload {
    public static final Type<OpenItemWishPacket> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(LuckyBlockMod.MOD_ID, "open_item_wish"));
    public static final StreamCodec<ByteBuf, OpenItemWishPacket> STREAM_CODEC = StreamCodec.unit(new OpenItemWishPacket());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public void handleClient(IPayloadContext context) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientItemWish::open);
    }
}
