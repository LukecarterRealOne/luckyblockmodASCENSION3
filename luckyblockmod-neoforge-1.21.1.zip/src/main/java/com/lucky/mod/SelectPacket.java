package com.lucky.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: ability picked in the menu (-1 = random) and whether to cast now. */
public record SelectPacket(int ability, boolean castNow) implements CustomPacketPayload {
    public static final Type<SelectPacket> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(LuckyBlockMod.MOD_ID, "select_ability"));
    public static final StreamCodec<ByteBuf, SelectPacket> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SelectPacket::ability,
            ByteBufCodecs.BOOL, SelectPacket::castNow,
            SelectPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public void handleServer(IPayloadContext context) {
        if (context.player() instanceof ServerPlayer sender) {
            LuckyBlockItem.onSelect(sender, ability, castNow);
        }
    }
}
