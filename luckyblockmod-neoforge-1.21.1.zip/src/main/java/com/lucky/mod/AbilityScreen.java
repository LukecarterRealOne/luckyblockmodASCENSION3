package com.lucky.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Compact, paginated Lucky Block menu (press G). */
public class AbilityScreen extends Screen {
    private static boolean castNow = false;
    private static int lastPage = 0;
    private int page;
    private int startX;
    private int startY;
    private int buttonWidth;
    private int buttonHeight;
    private int rowStep;
    private int navY;

    public AbilityScreen() {
        super(Component.literal("Lucky Block Abilities"));
        this.page = Math.max(0, Math.min(lastPage, pageCount() - 1));
    }

    private static int pageCount() {
        return (Abilities.COUNT + Abilities.PER_PAGE - 1) / Abilities.PER_PAGE;
    }

    private static Component modeText() {
        return Component.literal(castNow ? "CAST NOW  •  hold Lucky Block" : "SELECT  •  right-click to cast");
    }

    @Override
    protected void init() {
        clearWidgets();
        int margin = Math.max(8, this.width / 24);
        int gapX = 6;
        buttonWidth = Math.max(80, (this.width - margin * 2 - gapX) / 2);
        buttonHeight = this.height < 250 ? 18 : 20;
        rowStep = buttonHeight + 3;
        startX = margin;
        startY = this.height < 240 ? 42 : 49;
        for (int slot = 0; slot < Abilities.PER_PAGE; slot++) {
            final int ability = page * Abilities.PER_PAGE + slot;
            if (ability >= Abilities.COUNT) break;
            int x = startX + (slot % 2) * (buttonWidth + gapX);
            int y = startY + (slot / 2) * rowStep;
            String label = String.format("%02d  %s", ability + 1, Abilities.NAMES[ability]);
            addRenderableWidget(Button.builder(Component.literal(label), b -> choose(ability))
                    .bounds(x, y, buttonWidth, buttonHeight).build());
        }

        navY = this.height - (this.height < 240 ? 60 : 67);
        int navGap = 6;
        int prevWidth = Math.max(54, (this.width - 24) / 4);
        int randomWidth = Math.max(88, this.width / 3);
        int nextWidth = prevWidth;
        int navTotal = prevWidth + randomWidth + nextWidth + navGap * 2;
        int navX = (this.width - navTotal) / 2;
        addRenderableWidget(Button.builder(Component.literal("‹ Prev"), b -> changePage(-1))
                .bounds(navX, navY, prevWidth, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Random Roll"), b -> choose(-1))
                .bounds(navX + prevWidth + navGap, navY, randomWidth, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Next ›"), b -> changePage(1))
                .bounds(navX + prevWidth + navGap + randomWidth + navGap, navY, nextWidth, 20).build());

        int modeWidth = Math.min(260, this.width - 24);
        addRenderableWidget(Button.builder(modeText(), b -> {
            castNow = !castNow;
            b.setMessage(modeText());
        }).bounds((this.width - modeWidth) / 2, this.height - 27, modeWidth, 20).build());
    }

    private void changePage(int delta) {
        page = (page + delta + pageCount()) % pageCount();
        lastPage = page;
        rebuildWidgets();
    }

    private void choose(int id) {
        lastPage = page;
        ModNetworking.sendToServer(new SelectPacket(id, castNow));
        onClose();
    }

    private int hoveredAbility(double mouseX, double mouseY) {
        int gapX = 6;
        for (int slot = 0; slot < Abilities.PER_PAGE; slot++) {
            int id = page * Abilities.PER_PAGE + slot;
            if (id >= Abilities.COUNT) break;
            int x = startX + (slot % 2) * (buttonWidth + gapX);
            int y = startY + (slot / 2) * rowStep;
            if (mouseX >= x && mouseX < x + buttonWidth && mouseY >= y && mouseY < y + buttonHeight) {
                return id;
            }
        }
        return -1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, this.title, this.width / 2, 10, 0xFFFFFF);
        g.drawCenteredString(this.font, Component.literal("Choose a power  •  compact mode"), this.width / 2, 25, 0xFFD84A);
        g.drawCenteredString(this.font,
                Component.literal("Page " + (page + 1) + " / " + pageCount() + "   •   " + pageHeading()),
                this.width / 2, 37, 0xBFEFFF);
        int hovered = hoveredAbility(mouseX, mouseY);
        String description = hovered >= 0 ? Abilities.DESCRIPTIONS[hovered] : "Hover a power to see what it does.";
        g.drawCenteredString(this.font, Component.literal(description), this.width / 2,
                Math.min(this.height - 35, navY + 23), hovered >= 0 ? 0xFFFFFF : 0x9FA7B3);
    }

    private String pageHeading() {
        return switch (page) {
            case 0 -> "Core powers";
            case 1 -> "Summons & combat";
            case 2 -> "Time & space";
            default -> "Ascended powers";
        };
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
