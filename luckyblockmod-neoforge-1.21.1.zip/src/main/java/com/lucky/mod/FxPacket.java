package com.lucky.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.DistExecutor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: screen flash + camera shake. */
public record FxPacket(float flash, float shake, int duration, int color) implements CustomPacketPayload {
    public static final Type<FxPacket> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(LuckyBlockMod.MOD_ID, "fx"));
    public static final StreamCodec<ByteBuf, FxPacket> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.FLOAT, FxPacket::flash,
            ByteBufCodecs.FLOAT, FxPacket::shake,
            ByteBufCodecs.VAR_INT, FxPacket::duration,
            ByteBufCodecs.INT, FxPacket::color,
            FxPacket::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public void handleClient(IPayloadContext context) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientState.receive(flash, shake, duration, color));
    }
}
