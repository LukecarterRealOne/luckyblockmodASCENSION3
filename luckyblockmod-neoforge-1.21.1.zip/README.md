# Lucky Block Ascension — NeoForge 1.21.1

This project is a source port of Lucky Block Ascension from Forge 1.20.1 to **NeoForge 1.21.1**. It targets **Java 21** and NeoForge **21.1.x**.

## Build with GitHub Actions

1. Keep `.github/workflows/build.yml` in the repository.
2. Upload the extracted project files to the repository root, or upload this source archive as `luckyblockmod-neoforge-1.21.1.zip`.
3. Open the **Actions** tab and run **Build Lucky Block (NeoForge 1.21.1)**.
4. When the workflow completes successfully, download the `luckyblockmod-neoforge-1.21.1` artifact. It contains the mod JAR.

The workflow uses Java 21 and Gradle 9.2.1. This repository contains source code, not a precompiled JAR. A successful Actions build is required before installing it in Minecraft.

## Local build

Use JDK 21 and Gradle 9.2.1, then run:

```bash
gradle --no-daemon clean build
```

The mod JAR is written to `build/libs/`.

## In game

Install Minecraft 1.21.1 with NeoForge 21.1.x, then place the built JAR in your instance's `mods` folder.

- `/give @s luckyblockmod:lucky_block`
- Press **G** to open the compact, paginated ability picker.
- Right-click casts the selected power; selection defaults to a random power.
- Sneak + right-click casts Omega Beam.
- Carrying the Lucky Block in the main inventory or offhand grants passive flight in Survival/Adventure at 0.10 flying speed (twice the vanilla creative default). Double-tap jump to fly. Previous flight settings are restored when the block leaves the inventory.

## Port details

- Replaced Forge `SimpleChannel` with NeoForge custom payloads and `StreamCodec`.
- Migrated registry access, deferred registration, lifecycle events, tick events, item tooltip signature, and `neoforge.mods.toml` metadata for 1.21.1.
- Preserved the 34 abilities, projected 4D Tesseract VFX, layered impact effects, passive flight, searchable Item Wish catalogue, ally commands, and server-side item validation.
- Particle bursts, rings, and screen effects are rate-limited to reduce visual clutter.

## Verification status

Static checks have been run on the source delimiters, resource JSON/TOML, and workflow YAML/shell. A full Gradle compilation has **not** been completed in this environment because the Minecraft/NeoForge dependencies could not be downloaded here. Use the GitHub Actions build to verify compilation; if it reports a compiler error, share the first lines containing `error:`.
